<?php


$interet = " ";

$maRequete = "insert into Matable values(";

$maRequete .=  "'" . $_POST['nom'] . "'," . $_POST['age'] . ",'" . $_POST['marit'] . "',";

if (isset($_POST['internet'])) {
    $maRequete .= "1,";
    $interet .= " à Internet,";
} else {
    $maRequete .= "0,";
}

if (isset($_POST['micro'])) {
    $maRequete .= "1,";
    $interet .= ($interet == " ") ? " à la micro-informatique," : " la micro-informatique,";
} else {
    $maRequete .= "0,";
}

if (isset($_POST['jeux'])) {
    $maRequete .= "1)";
    $interet .= " aux jeux video.";
} else {
    $maRequete .= "0)";
}

if ($interet == " à") {
    $interet = " à rien (dommage...).";
}

if (substr($interet, -1) == ',') {
    $interet = substr($interet, 0, -1) . '.';
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Un petit formulaire</title>
</head>

<body>
    <?php
    echo '<h1>Merci à vous, ' . $_POST['nom'] . '</h1>';
    echo '<p>Vous avez donc le bel âge de <b>' . $_POST['age'] . '</b> ans, vous êtes <b> ' . $_POST['marit'] . '</b></p>';
    echo "<p>et vous vous intéressez <b>$interet</b></p>";

    echo "<p>Je m'empresse d'envoyer la requête :<br><b>$maRequete</b><br> à notre base données.</p>";
    ?>
</body>

</html>